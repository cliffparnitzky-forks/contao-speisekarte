<?php

$GLOBALS['TL_LANG']['MSC']['contao_speisekarte']['einheit']['Liter'] = 'l';
$GLOBALS['TL_LANG']['MSC']['contao_speisekarte']['einheit']['g'] = 'g';
$GLOBALS['TL_LANG']['MSC']['contao_speisekarte']['einheit']['kg'] = 'kg';
$GLOBALS['TL_LANG']['MSC']['contao_speisekarte']['einheit']['Stk'] = 'Stk';
