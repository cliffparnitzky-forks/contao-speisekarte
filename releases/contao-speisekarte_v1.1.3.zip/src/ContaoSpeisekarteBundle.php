<?php

namespace LinkingYou\ContaoSpeisekarte;

use Contao\System;
use Symfony\Component\HttpKernel\Bundle\Bundle;

class ContaoSpeisekarteBundle extends Bundle
{
}
