<?php

$GLOBALS['TL_LANG']['tl_contao_speisekarte_zusatzstoffe']['titel'] = array('Bezeichnung', '');
$GLOBALS['TL_LANG']['tl_contao_speisekarte_zusatzstoffe']['titel_legend'] = 'Zusatzstoff';
$GLOBALS['TL_LANG']['tl_contao_speisekarte_zusatzstoffe']['kuerzel'] = array('Kürzel', 'Kürzel für Legende');

$GLOBALS['TL_LANG']['tl_contao_speisekarte_zusatzstoffe']['edit'] = array('Zusatzstoff bearbeiten','Zusatzstoff ID %s bearbeiten');
$GLOBALS['TL_LANG']['tl_contao_speisekarte_zusatzstoffe']['new'] = array('Zusatzstoff anlegen','Neuen Zusatzstoff anlegen');
$GLOBALS['TL_LANG']['tl_contao_speisekarte_zusatzstoffe']['copy'] = array('Zusatzstoff kopieren','Zusatzstoff ID %s kopieren');
$GLOBALS['TL_LANG']['tl_contao_speisekarte_zusatzstoffe']['delete'] = array('Zusatzstoff löschen','Zusatzstoff ID %s löschen');
$GLOBALS['TL_LANG']['tl_contao_speisekarte_zusatzstoffe']['show'] = array('Details anzeigen','Details des Zusatzstoffs ID %s anzeigen');
