<?php

$GLOBALS['TL_LANG']['tl_contao_speisekarte_allergene']['titel'] = array('Bezeichnung', '');
$GLOBALS['TL_LANG']['tl_contao_speisekarte_allergene']['titel_legend'] = 'Allergen';
$GLOBALS['TL_LANG']['tl_contao_speisekarte_allergene']['kuerzel'] = array('Kürzel', 'Kürzel für Legende');

$GLOBALS['TL_LANG']['tl_contao_speisekarte_allergene']['edit'] = array('Allergen bearbeiten','Allergen ID %s bearbeiten');
$GLOBALS['TL_LANG']['tl_contao_speisekarte_allergene']['new'] = array('Allergen anlegen','Neues Allergen anlegen');
$GLOBALS['TL_LANG']['tl_contao_speisekarte_allergene']['copy'] = array('Allergen kopieren','Allergen ID %s kopieren');
$GLOBALS['TL_LANG']['tl_contao_speisekarte_allergene']['delete'] = array('Allergen löschen','Allergen ID %s löschen');
$GLOBALS['TL_LANG']['tl_contao_speisekarte_allergene']['show'] = array('Details anzeigen','Details des Allergens ID %s anzeigen');
