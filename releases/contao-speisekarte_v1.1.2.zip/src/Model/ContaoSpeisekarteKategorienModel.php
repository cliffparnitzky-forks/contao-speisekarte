<?php

namespace LinkingYou\ContaoSpeisekarte\Model;

use Contao\Model;

class ContaoSpeisekarteKategorienModel extends Model {

    /**
     * Name of the table
     * @var string
     */
    protected static $strTable = 'tl_contao_speisekarte_kategorien';

}
