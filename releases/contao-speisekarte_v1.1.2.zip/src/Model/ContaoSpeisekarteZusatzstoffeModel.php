<?php

namespace LinkingYou\ContaoSpeisekarte\Model;

use Contao\Model;

class ContaoSpeisekarteZusatzstoffeModel extends Model {

    /**
     * Name of the table
     * @var string
     */
    protected static $strTable = 'tl_contao_speisekarte_zusatzstoffe';

}
