<?php

namespace LinkingYou\ContaoSpeisekarte\Model;

use Contao\Model;

class ContaoSpeisekarteSpeisenModel extends Model {

    /**
     * Name of the table
     * @var string
     */
    protected static $strTable = 'tl_contao_speisekarte_speisen';

}
