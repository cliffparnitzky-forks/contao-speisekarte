<?php

$GLOBALS['TL_LANG']['FMD']['contao_speisekarte_speisekarte'] = array('Speisekarte');
$GLOBALS['TL_LANG']['tl_module']['contaospeisekarte_kategorien'] = array('Kategorien', 'Markieren Sie alle Kategorien, die ausgegeben werden sollen');
$GLOBALS['TL_LANG']['tl_module']['contaospeisekarte_zusatzstoffe'] = array('Zusatzstoffe', 'Legende für Zusatzstoffe ausgeben');
$GLOBALS['TL_LANG']['tl_module']['contaospeisekarte_allergene'] = array('Allergene', 'Legende für Allergene ausgeben');
