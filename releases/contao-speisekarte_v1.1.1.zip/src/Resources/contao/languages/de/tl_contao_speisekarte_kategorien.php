<?php

$GLOBALS['TL_LANG']['tl_contao_speisekarte_kategorien']['titel'] = array('Titel');
$GLOBALS['TL_LANG']['tl_contao_speisekarte_kategorien']['titel_legend'] = 'Kategorie';

$GLOBALS['TL_LANG']['tl_contao_speisekarte_kategorien']['editheader'] = array('Kategorie bearbeiten','Kategorie ID %s bearbeiten');
$GLOBALS['TL_LANG']['tl_contao_speisekarte_kategorien']['edit'] = array('Speisen bearbeiten','Speisen in Kategorie ID %s bearbeiten');
$GLOBALS['TL_LANG']['tl_contao_speisekarte_kategorien']['new'] = array('Kategorie anlegen','Neue Kategorie anlegen');
$GLOBALS['TL_LANG']['tl_contao_speisekarte_kategorien']['copy'] = array('Kategorie kopieren','Kategorie ID %s kopieren');
$GLOBALS['TL_LANG']['tl_contao_speisekarte_kategorien']['delete'] = array('Kategorie löschen','Kategorie ID %s löschen');
$GLOBALS['TL_LANG']['tl_contao_speisekarte_kategorien']['show'] = array('Kategorie anzeigen','Details der Kategorie ID %s anzeigen');
