<?php

$GLOBALS['TL_LANG']['tl_contao_speisekarte_speisen']['titel'] = array('Bezeichnung', '');
$GLOBALS['TL_LANG']['tl_contao_speisekarte_speisen']['titel_legend'] = 'Speise';
$GLOBALS['TL_LANG']['tl_contao_speisekarte_speisen']['nummer'] = array('Nummer', 'Speisen-Nummer (falls vorhanden)');
$GLOBALS['TL_LANG']['tl_contao_speisekarte_speisen']['beschreibung'] = array('Beschreibung', '');
$GLOBALS['TL_LANG']['tl_contao_speisekarte_speisen']['dishpic_legend'] = 'Bild';
$GLOBALS['TL_LANG']['tl_contao_speisekarte_speisen']['dishpic'] = array('Bild', '');
$GLOBALS['TL_LANG']['tl_contao_speisekarte_speisen']['preise_legend'] = 'Preise';
$GLOBALS['TL_LANG']['tl_contao_speisekarte_speisen']['menge'] = array('Menge', 'Menge oder Inhalt');
$GLOBALS['TL_LANG']['tl_contao_speisekarte_speisen']['preis'] = array('Preis', '');
$GLOBALS['TL_LANG']['tl_contao_speisekarte_speisen']['einheit'] = array('Einheit', '');
$GLOBALS['TL_LANG']['tl_contao_speisekarte_speisen']['grundpreis'] = array('Grundpreis', 'Soll Grundpreis berechnet werden?');
$GLOBALS['TL_LANG']['tl_contao_speisekarte_speisen']['zusatzstoffe_legende'] = 'Zusatzstoffe und Allergene';
$GLOBALS['TL_LANG']['tl_contao_speisekarte_speisen']['zusatzstoffe'] = array('Zusatzstoffe', '');
$GLOBALS['TL_LANG']['tl_contao_speisekarte_speisen']['allergene'] = array('Allergene', '');
$GLOBALS['TL_LANG']['tl_contao_speisekarte_speisen']['publish_legend'] = 'Veröffentlichung';
$GLOBALS['TL_LANG']['tl_contao_speisekarte_speisen']['published'] = array('Speise veröffentlichen', 'Die Speise auf der Webseite anzeigen.');

$GLOBALS['TL_LANG']['tl_contao_speisekarte_speisen']['edit'] = array('Speise bearbeiten','Speise ID %s bearbeiten');
$GLOBALS['TL_LANG']['tl_contao_speisekarte_speisen']['new'] = array('Speise anlegen','Neue Speise anlegen');
$GLOBALS['TL_LANG']['tl_contao_speisekarte_speisen']['copy'] = array('Speise kopieren','Speise ID %s kopieren');
$GLOBALS['TL_LANG']['tl_contao_speisekarte_speisen']['delete'] = array('Speise löschen','Speise ID %s löschen');
$GLOBALS['TL_LANG']['tl_contao_speisekarte_speisen']['toggle'] = array('Speise veröffentlichen/unveröffentlichen','Speise ID %s veröffentlichen/unveröffentlichen');
$GLOBALS['TL_LANG']['tl_contao_speisekarte_speisen']['show'] = array('Details anzeigen','Details der Speise ID %s anzeigen');
