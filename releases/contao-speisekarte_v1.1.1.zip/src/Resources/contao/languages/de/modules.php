<?php

$GLOBALS['TL_LANG']['MOD']['contao_speisekarte'] = array('Speisekarte', 'Speisekarte verwalten');
$GLOBALS['TL_LANG']['FMD']['contao_speisekarte'] = array('Speisekarte', 'Speisekarte verwalten');
$GLOBALS['TL_LANG']['FMD']['contao_speisekarte_speisekarte'] = array('Speisekarte', 'Stellt eine Speisekarte dar');

$GLOBALS['TL_LANG']['MOD']['contao_speisekarte_speisen'] = array('Speisen');
$GLOBALS['TL_LANG']['MOD']['contao_speisekarte_zusatzstoffe'] = array('Zusatzstoffe');
$GLOBALS['TL_LANG']['MOD']['contao_speisekarte_allergene'] = array('Allergene');
